
// Typed Text
var typed = new Typed('#typed', {
    stringsElement: '#typed-strings',
    typeSpeed: 200,
    loop: true,
    strings: [
        'Angular Developer', 'React Developer', 'NodeJs Developer',
    ],
});