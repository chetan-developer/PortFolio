// Contact Form
function validateForm() {
  var name = document.forms["myForm"]["name"].value;
  var email = document.forms["myForm"]["email"].value;
  var subject = document.forms["myForm"]["subject"].value;
  var comments = document.forms["myForm"]["comments"].value;
  document.getElementById("error-msg").style.opacity = 0;
  document.getElementById('error-msg').innerHTML = "";
  document.getElementById("simple-msg").style.opacity = 0;
  document.getElementById('simple-msg').innerHTML = "";
  if (name == "" || name == null) {
    document.getElementById('error-msg').innerHTML = "<div class='alert alert-warning error_message'>*Please enter a Name*</div>";
    fadeIn();
    return false;
  }
  if (email == "" || email == null) {
    document.getElementById('error-msg').innerHTML = "<div class='alert alert-warning error_message'>*Please enter a Email*</div>";
    fadeIn();
    return false;
  }
  if (subject == "" || subject == null) {
    document.getElementById('error-msg').innerHTML = "<div class='alert alert-warning error_message'>*Please enter a Subject*</div>";
    fadeIn();
    return false;
  }
  if (comments == "" || comments == null) {
    document.getElementById('error-msg').innerHTML = "<div class='alert alert-warning error_message'>*Please enter a Comments*</div>";
    fadeIn();
    return false;
  }
  debugger;
  var xhttp = new XMLHttpRequest();

  const Data = {
    Name: name.trim(),
    Email: email.trim(),
    Subject: subject.trim(),
    Message: comments.trim()
  };

  Loader(true)
  fetch('https://idonttrust.me/api/Account/SendMailFromMainSite', {
    method: "POST",
    body: JSON.stringify(Data),
    headers: { "Content-type": "application/json; charset=UTF-8" }
  }).then(response => response.json())
    .then(json => {
      debugger;
      Loader(false)
      if (json.status == false) {
        document.getElementById('error-msg').innerHTML = `<div class='alert alert-warning error_message'>*${json.message}*</div>`
        fadeIn();
        return false;
      } else {
        document.getElementById("simple-msg").style.opacity = 1;
        document.getElementById("simple-msg").innerHTML = `<div class='alert alert-success success_message'>*${json.message}*</div>`
        document.forms["myForm"]["name"].value = "";
        document.forms["myForm"]["email"].value = "";
        document.forms["myForm"]["subject"].value = "";
        document.forms["myForm"]["comments"].value = "";
      }
    })
    .catch(err => {
      debugger
      Loader(false)
      document.getElementById('error-msg').innerHTML = `<div class='alert alert-warning error_message'>*${err.message}*</div>`;
    });




  // setTimeout(() => {
  //   document.getElementById('preloader').style.visibility = 'visible';
  //   document.getElementById('preloader').style.opacity = '1';
  // }, 350);

  // xhttp.onreadystatechange = function () {
  //   if (this.readyState == 4 && this.status == 200) {
  //     document.getElementById("simple-msg").innerHTML = this.responseText;
  //     document.forms["myForm"]["name"].value = "";
  //     document.forms["myForm"]["email"].value = "";
  //     document.forms["myForm"]["subject"].value = "";
  //     document.forms["myForm"]["comments"].value = "";
  //   }
  // };
  // xhttp.open("POST", "php/contact.php", true);
  // xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  // xhttp.send("name=" + name + "&email=" + email + "&subject=" + subject + "&comments=" + comments);
  return false;
}

function Loader(isVisible) {
  if (isVisible) {
    document.getElementById('preloader').style.visibility = 'visible';
    document.getElementById('preloader').style.opacity = '1';
  } else {
    document.getElementById('preloader').style.visibility = 'hidden';
    document.getElementById('preloader').style.opacity = '0';
  }
}

function fadeIn() {
  var fade = document.getElementById("error-msg");
  var opacity = 0;
  var intervalID = setInterval(function () {
    if (opacity < 1) {
      opacity = opacity + 0.5
      fade.style.opacity = opacity;
    } else {
      clearInterval(intervalID);
    }
  }, 200);
}